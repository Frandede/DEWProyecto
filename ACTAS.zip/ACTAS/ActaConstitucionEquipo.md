# Acta de Constitución del Equipo de Trabajo

**Fecha de la reunión:** 07/05/2025
**Hora de inicio:** 13:00
**Hora de finalización:** 14:20
**Lugar / Medio:** ETSINF 

---

## 1. Integrantes del equipo

| Nombre completo                 | Correo UPV                  |
|---------------------------------|-----------------------------|
| Lluis Colomar García            | lcolgar@etsinf.upv.es       | 
| Aarón Montaraz Gomez            | amongom@etsinf.upv.es       |
| Francisco de la Guia Gonzalez   | fdelag@etsinf.upv.es        |
| Raúl Medrano Llopis             | rmedllo@etsinf.upv.es       |
| Jara Leal García                | jleagar@etsinf.upv.es       |
| Pau Zaragozà Carrascosa         | pzarcar@etsinf.upv.es       |

---

## 2. Rol de secretario/a

Se acuerda que **Pau Zaragozà Carrascosa** ejercerá el rol de **secretario**, encargado de redactar las actas de todas las reuniones.

---

## 3. Herramientas de coordinación y repositorio común

- **Comunicación:** Servidor de Discord: https://discord.gg/NXRr2xrD
- **Repositorio de trabajo:** [Repositorio en GitHub](https://github.com/Frandede/DEWProyecto.git) 
  - Contendrá código fuente, actas, documentación y recursos adicionales.

---

## 4. Expectativas y dedicación de los miembros

Como primera toma de contacto con el proyecto nos distribuiremos el trabajop en las siguientes reuniones, por el momento leeremos la guia y nos familiarizaremos con los posibles objetivos a alcanzar.

| Miembro                         | Expectativas y disponibilidad                  |               |
|---------------------------------|------------------------------------------------|
| Lluis Colomar García            |       Leer la GUIA                             | 
| Aarón Montaraz Gomez            |       Leer la GUIA                             |
| Francisco de la Guia Gonzalez   |       Leer la GUIA                             |
| Raúl Medrano Llopis             |       Leer la GUIA                             |
| Jara Leal García                |       Leer la GUIA                             |
| Pau Zaragozà Carrascosa         |       Leer la GUIA y Interés en documentación. |

Se acuerda que todos los miembros participarán activamente y de forma equitativa en el trabajo, respetando los acuerdos establecidos.

---

## 5. Modalidad de reuniones

- **Durante sesiones prácticas:** Presenciales en aula asignada.
- **Fuera del horario lectivo:** Reuniones online por Discord.
- Se registrará acta en cada una de ellas, a validar al final del encuentro.
- De ser necesario una reunión en persona fuera del horario de practicas se especificaria la fecha y lugar de la misma.
---

## 6. Validación

Los miembros del equipo confirman haber leído y aceptado el contenido de esta acta.

|  Nombre completo                | Firma (Nombre) |
|---------------------------------|----------------|
| Lluis Colomar García            |     LLUIS      | 
| Aarón Montaraz Gomez            |     AARÓN      |
| Francisco de la Guia Gonzalez   |     FRANCISCO  |
| Raúl Medrano Llopis             |     RAÚL       |
| Jara Leal García                |     JARA       |
| Pau Zaragozà Carrascosa         |     PAU        |

---

**Fin del acta**

