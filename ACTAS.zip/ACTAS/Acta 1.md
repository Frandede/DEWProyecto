# Acta de Reunión del Equipo de Trabajo 

**Fecha de la reunión:**<!-- DD/MM/AAAA -->  
**Hora de inicio:** <!-- HH:MM -->  
**Hora de finalización:** <!-- HH:MM -->  
**Lugar / Medio:** <!-- Aula / Teams / Otro -->

---

## 1. Asistentes

| Nombre completo                 | Presente (Sí/No) |
|---------------------------------|------------------|
| Lluis Colomar García            |                | 
| Aarón Montaraz Gomez            |                |
| Francisco de la Guia Gonzalez   |                |
| Raúl Medrano Llopis             |                |
| Jara Leal García                |                |
| Pau Zaragozà Carrascosa         |                |

---

## 2. Orden del día

1. <!-- Tema 1 tratado -->
2. <!-- Tema 2 tratado -->
3. <!-- Tema 3 tratado -->

---

## 3. Desarrollo de la reunión

- **Resumen general:** 
  <!-- Breve resumen de lo hablado, conclusiones principales. -->

- **Decisiones tomadas:** 
  - <!-- Ej: Se acordó usar la librería X para realizar la conexión con la base de datos. -->
  - <!-- Ej: El diseño del login se aprobará en la próxima reunión. -->

- **Problemas/dificultades detectadas:** 
  - <!-- Ej: Incompatibilidad entre herramientas propuestas. -->
  - <!-- Ej: Falta de disponibilidad de algunos miembros. -->

---

## 4. Reparto de tareas

| Tarea                               | Responsable            | Fecha límite       |
|-------------------------------------|------------------------|---------------------|
| <!-- Ej: Implementar formulario --> | <!-- Ej: María Sánchez --> | <!-- 14/05/2025 --> |
|                                     |                        |                     |

---

## 5. Próxima reunión

- **Fecha prevista:** <!-- DD/MM/AAAA --> 
- **Hora:** <!-- HH:MM --> 
- **Lugar / Medio:** <!-- Aula / Teams / Otro -->

---

## 6. Validación del acta

|  Nombre completo                | Firma (Nombre) |
|---------------------------------|----------------|
| Lluis Colomar García            |     LLUIS      | 
| Aarón Montaraz Gomez            |     AARÓN      |
| Francisco de la Guia Gonzalez   |     FRANCISCO  |
| Raúl Medrano Llopis             |     RAÚL       |
| Jara Leal García                |     JARA       |
| Pau Zaragozà Carrascosa         |     PAU        |
---

**Fin del acta**

